.class public Lcom/osunhive/v3/osunhiveytgetkeyv3;
.super Ljava/lang/Object;
.source "osunhiveytgetkeyv3.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/osunhive/v3/osunhiveytgetkeyv3$VerifyTimeTask;,
        Lcom/osunhive/v3/osunhiveytgetkeyv3$100000000;,
        Lcom/osunhive/v3/osunhiveytgetkeyv3$100000001;,
        Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;,
        Lcom/osunhive/v3/osunhiveytgetkeyv3$100000004;,
        Lcom/osunhive/v3/osunhiveytgetkeyv3$100000005;,
        Lcom/osunhive/v3/osunhiveytgetkeyv3$FetchConfigTask;,
        Lcom/osunhive/v3/osunhiveytgetkeyv3$ShortenUrlTask;,
        Lcom/osunhive/v3/osunhiveytgetkeyv3$100000006;
    }
.end annotation


# static fields
.field private static final ADMIN_PANEL_URL:Ljava/lang/String; = "https://t.me/osunhive"

.field private static final COLOR_BORDER_GOLD:I = -0x2900

.field private static final COLOR_BORDER_SILVER:I = -0xaaaaab

.field private static final GRADIENT_GOLD:[I

.field private static final GRADIENT_METAL_BTN:[I

.field private static final GRADIENT_METAL_CARD:[I

.field private static final JSON_CONFIG_URL:Ljava/lang/String; = "https://pastebin.com/raw/kV1nnyvT"

.field private static final KEY_BASE_URL:Ljava/lang/String; = "https://www.osunhive.name.ng/p/key-by-osunhive.htmll"

.field private static final KEY_EXPIRY_TIME:Ljava/lang/String; = "expiry_time_server"

.field private static final L1:[I

.field private static final L2:[I

.field private static final L3:[I

.field private static final P1:[I

.field private static final P2:[I

.field private static final P3:[I

.field private static final PREFS_NAME:Ljava/lang/String; = "OsunhiveKeyPrefs"

.field private static currentSessionKey:Ljava/lang/String;

.field private static fetchedApiToken:Ljava/lang/String;

.field private static fetchedApiUrl:Ljava/lang/String;


# direct methods
.method static final constructor <clinit>()V
    .registers 4

    const/16 v0, 0x6d

    const/16 v1, 0x2e

    const/16 v2, 0x63

    const/16 v3, 0x6f

    filled-new-array {v2, v3, v0, v1}, [I

    move-result-object v0

    sput-object v0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->P1:[I

    const/16 v0, 0x9

    new-array v0, v0, [I

    fill-array-data v0, :array_6c

    sput-object v0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->P2:[I

    const/16 v0, 0x15

    new-array v0, v0, [I

    fill-array-data v0, :array_82

    sput-object v0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->P3:[I

    const/16 v0, 0x8

    new-array v1, v0, [I

    fill-array-data v1, :array_b0

    sput-object v1, Lcom/osunhive/v3/osunhiveytgetkeyv3;->L1:[I

    const/16 v1, 0xb

    new-array v1, v1, [I

    fill-array-data v1, :array_c4

    sput-object v1, Lcom/osunhive/v3/osunhiveytgetkeyv3;->L2:[I

    new-array v0, v0, [I

    fill-array-data v0, :array_de

    sput-object v0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->L3:[I

    const v0, -0xe1e1e2

    const/high16 v1, -0x1000000

    const v2, -0xc7c7c8

    filled-new-array {v2, v0, v1}, [I

    move-result-object v0

    sput-object v0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->GRADIENT_METAL_CARD:[I

    const v0, -0xd7d7d8

    const v1, -0xefeff0

    const v2, -0xafafb0

    filled-new-array {v2, v0, v1}, [I

    move-result-object v0

    sput-object v0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->GRADIENT_METAL_BTN:[I

    const/16 v0, -0x2900

    const v1, -0x4779f5

    const/16 v2, -0x1f9a

    filled-new-array {v2, v0, v1}, [I

    move-result-object v0

    sput-object v0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->GRADIENT_GOLD:[I

    const-string v0, ""

    sput-object v0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->currentSessionKey:Ljava/lang/String;

    sput-object v0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->fetchedApiUrl:Ljava/lang/String;

    sput-object v0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->fetchedApiToken:Ljava/lang/String;

    return-void

    :array_6c
    .array-data 4
        0x6f
        0x73
        0x75
        0x6e
        0x68
        0x69
        0x76
        0x65
        0x2e
    .end array-data

    :array_82
    .array-data 4
        0x76
        0x33
        0x2e
        0x6f
        0x73
        0x75
        0x6e
        0x68
        0x69
        0x76
        0x65
        0x79
        0x74
        0x67
        0x65
        0x74
        0x6b
        0x65
        0x79
        0x76
        0x33
    .end array-data

    :array_b0
    .array-data 4
        0x68
        0x74
        0x74
        0x70
        0x73
        0x3a
        0x2f
        0x2f
    .end array-data

    :array_c4
    .array-data 4
        0x79
        0x6f
        0x75
        0x74
        0x75
        0x62
        0x65
        0x2e
        0x63
        0x6f
        0x6d
    .end array-data

    :array_de
    .array-data 4
        0x2f
        0x40
        0x64
        0x70
        0x6d
        0x6f
        0x64
        0x73
    .end array-data
.end method

.method public constructor <init>()V
    .registers 1

    .line 483
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic access$1000028(Landroid/app/Activity;)V
    .registers 1

    invoke-static {p0}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->showKeyDialog(Landroid/app/Activity;)V

    return-void
.end method

.method static synthetic access$1000036(Landroid/content/Context;)Z
    .registers 1

    invoke-static {p0}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->isInternetAvailable(Landroid/content/Context;)Z

    move-result p0

    return p0
.end method

.method static synthetic access$L1000000()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->JSON_CONFIG_URL:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$L1000001()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->PREFS_NAME:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$L1000002()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->KEY_EXPIRY_TIME:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$L1000003()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->KEY_BASE_URL:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$L1000004()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->ADMIN_PANEL_URL:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$L1000016()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->currentSessionKey:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$L1000017()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->fetchedApiUrl:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$L1000018()Ljava/lang/String;
    .registers 1

    sget-object v0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->fetchedApiToken:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$S1000000(Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->JSON_CONFIG_URL:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000001(Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->PREFS_NAME:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000002(Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->KEY_EXPIRY_TIME:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000003(Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->KEY_BASE_URL:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000004(Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->ADMIN_PANEL_URL:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000016(Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->currentSessionKey:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000017(Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->fetchedApiUrl:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$S1000018(Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->fetchedApiToken:Ljava/lang/String;

    return-void
.end method

.method private static addSpacer(Landroid/content/Context;Landroid/widget/LinearLayout;I)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/widget/LinearLayout;",
            "I)V"
        }
    .end annotation

    .line 423
    new-instance v0, Landroid/view/View;

    invoke-direct {v0, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance p0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x1

    invoke-direct {p0, v1, p2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, p0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void
.end method

.method private static checkIntegrity(Landroid/app/Activity;)Z
    .registers 5

    .line 95
    :try_start_0
    const-string v0, "com.osunhive.v3.osunhiveytgetkeyv3"

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0
    :try_end_6
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_6} :catch_4b

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    .line 96
    new-instance v1, Ljava/lang/StringBuffer;

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v2, Ljava/lang/StringBuffer;

    invoke-direct {v2}, Ljava/lang/StringBuffer;-><init>()V

    sget-object v3, Lcom/osunhive/v3/osunhiveytgetkeyv3;->P1:[I

    invoke-static {v3}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->d([I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    sget-object v3, Lcom/osunhive/v3/osunhiveytgetkeyv3;->P2:[I

    invoke-static {v3}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->d([I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v1

    sget-object v2, Lcom/osunhive/v3/osunhiveytgetkeyv3;->P3:[I

    invoke-static {v2}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->d([I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    .line 97
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_49

    .line 98
    invoke-static {p0}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->triggerSecurityProtocol(Landroid/app/Activity;)V

    .line 99
    const/4 p0, 0x0

    return p0

    .line 101
    :cond_49
    const/4 p0, 0x1

    return p0

    .line 95
    :catch_4b
    move-exception p0

    new-instance v0, Ljava/lang/NoClassDefFoundError;

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/NoClassDefFoundError;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method private static createCornerDecoration(Landroid/content/Context;Ljava/lang/String;)Landroid/view/View;
    .registers 3

    .line 389
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    .line 390
    invoke-virtual {v0, p1}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object p1

    .line 391
    invoke-static {p1}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object v0

    .line 392
    invoke-virtual {p1}, Ljava/io/InputStream;->close()V

    .line 393
    new-instance p1, Landroid/widget/ImageView;

    invoke-direct {p1, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 394
    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    .line 395
    sget-object p0, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {p1, p0}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V
    :try_end_1c
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_1c} :catch_1d

    .line 396
    return-object p1

    :catch_1d
    move-exception p0

    .line 397
    const/4 p0, 0x0

    move-object p1, p0

    check-cast p1, Landroid/view/View;

    return-object p0
.end method

.method private static createEmbossedBg([IIII)Landroid/graphics/drawable/GradientDrawable;
    .registers 6

    .line 401
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    sget-object v1, Landroid/graphics/drawable/GradientDrawable$Orientation;->TOP_BOTTOM:Landroid/graphics/drawable/GradientDrawable$Orientation;

    invoke-direct {v0, v1, p0}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    .line 402
    int-to-float p0, p3

    invoke-virtual {v0, p0}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 403
    if-lez p1, :cond_10

    invoke-virtual {v0, p1, p2}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 404
    :cond_10
    return-object v0
.end method

.method private static createEmbossedButton(Landroid/content/Context;Ljava/lang/String;[IIZ)Landroid/widget/Button;
    .registers 6

    .line 409
    new-instance v0, Landroid/widget/Button;

    invoke-direct {v0, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 410
    invoke-virtual {v0, p1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 411
    invoke-virtual {v0, p3}, Landroid/widget/Button;->setTextColor(I)V

    .line 412
    sget-object p0, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setTypeface(Landroid/graphics/Typeface;)V

    .line 413
    const p0, -0xaaaaab

    const/16 p1, 0xf

    const/4 p3, 0x2

    invoke-static {p2, p3, p0, p1}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->createEmbossedBg([IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 414
    if-eqz p4, :cond_2e

    .line 415
    const/16 p0, 0xc

    int-to-float p0, p0

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setTextSize(F)V

    .line 416
    const/16 p0, 0x50

    invoke-virtual {v0, p0}, Landroid/widget/Button;->setHeight(I)V

    .line 417
    const/4 p0, 0x0

    invoke-virtual {v0, p0, p0, p0, p0}, Landroid/widget/Button;->setPadding(IIII)V

    .line 419
    :cond_2e
    return-object v0
.end method

.method private static d([I)Ljava/lang/String;
    .registers 4

    .line 113
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 114
    const/4 v1, 0x0

    :goto_6
    array-length v2, p0

    if-lt v1, v2, :cond_e

    .line 115
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 114
    :cond_e
    aget v2, p0, v1

    int-to-char v2, v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    add-int/lit8 v1, v1, 0x1

    goto :goto_6
.end method

.method private static getDropInAnim()Landroid/view/animation/AnimationSet;
    .registers 13

    .line 366
    new-instance v0, Landroid/view/animation/AnimationSet;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/view/animation/AnimationSet;-><init>(Z)V

    .line 367
    new-instance v2, Landroid/view/animation/OvershootInterpolator;

    const v3, 0x3f99999a  # 1.2f

    invoke-direct {v2, v3}, Landroid/view/animation/OvershootInterpolator;-><init>(F)V

    invoke-virtual {v0, v2}, Landroid/view/animation/AnimationSet;->setInterpolator(Landroid/view/animation/Interpolator;)V

    .line 368
    invoke-virtual {v0, v1}, Landroid/view/animation/AnimationSet;->setFillAfter(Z)V

    .line 369
    new-instance v1, Landroid/view/animation/TranslateAnimation;

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/high16 v10, -0x40800000  # -1.0f

    const/4 v11, 0x1

    const/4 v12, 0x0

    move-object v4, v1

    invoke-direct/range {v4 .. v12}, Landroid/view/animation/TranslateAnimation;-><init>(IFIFIFIF)V

    .line 370
    const/16 v2, 0x320

    int-to-long v2, v2

    invoke-virtual {v1, v2, v3}, Landroid/view/animation/TranslateAnimation;->setDuration(J)V

    .line 371
    new-instance v2, Landroid/view/animation/AlphaAnimation;

    const/4 v3, 0x0

    const/high16 v4, 0x3f800000  # 1.0f

    invoke-direct {v2, v3, v4}, Landroid/view/animation/AlphaAnimation;-><init>(FF)V

    .line 372
    const/16 v3, 0x190

    int-to-long v3, v3

    invoke-virtual {v2, v3, v4}, Landroid/view/animation/AlphaAnimation;->setDuration(J)V

    .line 373
    invoke-virtual {v0, v1}, Landroid/view/animation/AnimationSet;->addAnimation(Landroid/view/animation/Animation;)V

    .line 374
    invoke-virtual {v0, v2}, Landroid/view/animation/AnimationSet;->addAnimation(Landroid/view/animation/Animation;)V

    .line 375
    const/16 v1, 0xc8

    int-to-long v1, v1

    invoke-virtual {v0, v1, v2}, Landroid/view/animation/AnimationSet;->setStartOffset(J)V

    .line 376
    return-object v0
.end method

.method private static getSpringAnim()Landroid/view/animation/AnimationSet;
    .registers 13

    .line 353
    new-instance v0, Landroid/view/animation/AnimationSet;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/view/animation/AnimationSet;-><init>(Z)V

    .line 354
    new-instance v2, Landroid/view/animation/OvershootInterpolator;

    const/high16 v3, 0x3fc00000  # 1.5f

    invoke-direct {v2, v3}, Landroid/view/animation/OvershootInterpolator;-><init>(F)V

    invoke-virtual {v0, v2}, Landroid/view/animation/AnimationSet;->setInterpolator(Landroid/view/animation/Interpolator;)V

    .line 355
    invoke-virtual {v0, v1}, Landroid/view/animation/AnimationSet;->setFillAfter(Z)V

    .line 356
    new-instance v1, Landroid/view/animation/ScaleAnimation;

    const/high16 v5, 0x3f000000  # 0.5f

    const/high16 v6, 0x3f800000  # 1.0f

    const/high16 v7, 0x3f000000  # 0.5f

    const/high16 v8, 0x3f800000  # 1.0f

    const/4 v9, 0x1

    const/high16 v10, 0x3f000000  # 0.5f

    const/4 v11, 0x1

    const/high16 v12, 0x3f000000  # 0.5f

    move-object v4, v1

    invoke-direct/range {v4 .. v12}, Landroid/view/animation/ScaleAnimation;-><init>(FFFFIFIF)V

    .line 357
    const/16 v2, 0x2bc

    int-to-long v2, v2

    invoke-virtual {v1, v2, v3}, Landroid/view/animation/ScaleAnimation;->setDuration(J)V

    .line 358
    new-instance v2, Landroid/view/animation/AlphaAnimation;

    const/4 v3, 0x0

    const/high16 v4, 0x3f800000  # 1.0f

    invoke-direct {v2, v3, v4}, Landroid/view/animation/AlphaAnimation;-><init>(FF)V

    .line 359
    const/16 v3, 0x190

    int-to-long v3, v3

    invoke-virtual {v2, v3, v4}, Landroid/view/animation/AlphaAnimation;->setDuration(J)V

    .line 360
    invoke-virtual {v0, v1}, Landroid/view/animation/AnimationSet;->addAnimation(Landroid/view/animation/Animation;)V

    .line 361
    invoke-virtual {v0, v2}, Landroid/view/animation/AnimationSet;->addAnimation(Landroid/view/animation/Animation;)V

    .line 362
    return-object v0
.end method

.method public static getkeybydp(Landroid/app/Activity;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            ")V"
        }
    .end annotation

    .line 86
    invoke-static {p0}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->checkIntegrity(Landroid/app/Activity;)Z

    move-result v0

    if-nez v0, :cond_7

    return-void

    .line 87
    :cond_7
    invoke-static {p0}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->isInternetAvailable(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_11

    .line 88
    invoke-static {p0}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->showNoInternetDialog(Landroid/app/Activity;)V

    .line 89
    return-void

    .line 91
    :cond_11
    new-instance v0, Lcom/osunhive/v3/osunhiveytgetkeyv3$VerifyTimeTask;

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Landroid/app/Dialog;

    const/4 v2, 0x1

    invoke-direct {v0, p0, v1, v2}, Lcom/osunhive/v3/osunhiveytgetkeyv3$VerifyTimeTask;-><init>(Landroid/app/Activity;Landroid/app/Dialog;Z)V

    const/4 p0, 0x0

    new-array p0, p0, [Ljava/lang/Void;

    invoke-virtual {v0, p0}, Lcom/osunhive/v3/osunhiveytgetkeyv3$VerifyTimeTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    return-void
.end method

.method private static isInternetAvailable(Landroid/content/Context;)Z
    .registers 2

    .line 475
    const-string v0, "connectivity"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/net/ConnectivityManager;

    invoke-virtual {p0}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object p0

    if-eqz p0, :cond_17

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->isConnectedOrConnecting()Z

    move-result p0

    if-nez p0, :cond_15

    goto :goto_17

    :cond_15
    const/4 p0, 0x1

    goto :goto_18

    :cond_17
    :goto_17
    const/4 p0, 0x0

    :goto_18
    return p0
.end method

.method private static showKeyDialog(Landroid/app/Activity;)V
    .registers 22
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            ")V"
        }
    .end annotation

    .line 119
    move-object/from16 v1, p0

    new-instance v2, Landroid/app/Dialog;

    invoke-direct {v2, v1}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    .line 120
    const/4 v0, 0x1

    invoke-virtual {v2, v0}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    .line 121
    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/app/Dialog;->setCancelable(Z)V

    .line 122
    invoke-virtual {v2}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v4

    const/4 v5, -0x1

    if-eqz v4, :cond_33

    .line 123
    invoke-virtual {v2}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v4

    new-instance v6, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v6, v3}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v4, v6}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 124
    invoke-virtual {v2}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v4

    invoke-virtual {v4, v5, v5}, Landroid/view/Window;->setLayout(II)V

    .line 125
    invoke-virtual {v2}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v4

    const v6, 0x3f59999a  # 0.85f

    invoke-virtual {v4, v6}, Landroid/view/Window;->setDimAmount(F)V

    .line 129
    :cond_33
    invoke-virtual/range {p0 .. p0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v4

    .line 130
    iget v6, v4, Landroid/util/DisplayMetrics;->widthPixels:I

    .line 131
    iget v4, v4, Landroid/util/DisplayMetrics;->heightPixels:I

    .line 132
    if-gt v6, v4, :cond_43

    const/4 v4, 0x0

    goto :goto_44

    :cond_43
    const/4 v4, 0x1

    .line 136
    :goto_44
    int-to-double v6, v6

    if-eqz v4, :cond_4d

    const-wide v8, 0x3fe199999999999aL  # 0.55

    goto :goto_52

    :cond_4d
    const-wide v8, 0x3feb333333333333L  # 0.85

    :goto_52
    mul-double v6, v6, v8

    double-to-int v6, v6

    .line 139
    if-eqz v4, :cond_5a

    const/16 v7, 0x50

    goto :goto_63

    :cond_5a
    int-to-double v7, v6

    const-wide v9, 0x3fd6666666666666L  # 0.35

    mul-double v7, v7, v9

    double-to-int v7, v7

    .line 142
    :goto_63
    if-eqz v4, :cond_68

    const/16 v9, 0xa

    goto :goto_6a

    :cond_68
    const/16 v9, 0x1c2

    .line 143
    :goto_6a
    if-eqz v4, :cond_6f

    const/16 v10, 0xa

    goto :goto_71

    :cond_6f
    const/16 v10, 0x64

    .line 146
    :goto_71
    if-eqz v4, :cond_75

    const/4 v12, 0x5

    goto :goto_77

    :cond_75
    const/16 v12, 0x14

    .line 151
    :goto_77
    new-instance v13, Landroid/widget/ScrollView;

    invoke-direct {v13, v1}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 152
    invoke-virtual {v13, v0}, Landroid/widget/ScrollView;->setFillViewport(Z)V

    .line 153
    invoke-virtual {v13, v3}, Landroid/widget/ScrollView;->setBackgroundColor(I)V

    .line 154
    invoke-virtual {v13, v3}, Landroid/widget/ScrollView;->setClipChildren(Z)V

    .line 155
    invoke-virtual {v13, v3}, Landroid/widget/ScrollView;->setClipToPadding(Z)V

    .line 157
    invoke-virtual {v13, v3}, Landroid/widget/ScrollView;->setVerticalScrollBarEnabled(Z)V

    .line 159
    new-instance v14, Landroid/widget/FrameLayout;

    invoke-direct {v14, v1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 160
    invoke-virtual {v14, v3}, Landroid/widget/FrameLayout;->setClipChildren(Z)V

    .line 161
    invoke-virtual {v14, v3}, Landroid/widget/FrameLayout;->setClipToPadding(Z)V

    .line 162
    const/16 v15, 0x1e

    invoke-virtual {v14, v15, v9, v15, v10}, Landroid/widget/FrameLayout;->setPadding(IIII)V

    .line 164
    new-instance v9, Landroid/widget/RelativeLayout;

    invoke-direct {v9, v1}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;)V

    .line 165
    invoke-virtual {v9, v3}, Landroid/widget/RelativeLayout;->setClipChildren(Z)V

    .line 166
    invoke-virtual {v9, v3}, Landroid/widget/RelativeLayout;->setClipToPadding(Z)V

    .line 168
    new-instance v10, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v11, -0x2

    invoke-direct {v10, v6, v11}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 169
    const/16 v6, 0x11

    iput v6, v10, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 170
    invoke-virtual {v9, v10}, Landroid/widget/RelativeLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 173
    new-instance v10, Landroid/widget/LinearLayout;

    invoke-direct {v10, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 174
    invoke-static {}, Landroid/view/View;->generateViewId()I

    move-result v8

    .line 175
    invoke-virtual {v10, v8}, Landroid/widget/LinearLayout;->setId(I)V

    .line 176
    invoke-virtual {v10, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 177
    sget-object v0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->GRADIENT_METAL_CARD:[I

    const v3, -0xaaaaab

    const/4 v5, 0x2

    invoke-static {v0, v5, v3, v15}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->createEmbossedBg([IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {v10, v0}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 179
    if-eqz v4, :cond_d4

    const/16 v0, 0xa

    goto :goto_d6

    :cond_d4
    const/16 v0, 0x14

    :goto_d6
    add-int/2addr v0, v7

    const/16 v3, 0x28

    invoke-virtual {v10, v3, v0, v3, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 180
    invoke-virtual {v10, v6}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 182
    new-instance v0, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v5, -0x1

    invoke-direct {v0, v5, v11}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    .line 183
    const/16 v5, 0xd

    invoke-virtual {v0, v5}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    .line 185
    div-int/lit8 v5, v7, 0x2

    const/4 v15, 0x0

    invoke-virtual {v0, v15, v5, v15, v15}, Landroid/widget/RelativeLayout$LayoutParams;->setMargins(IIII)V

    .line 186
    invoke-virtual {v10, v0}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 187
    invoke-static {}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->getSpringAnim()Landroid/view/animation/AnimationSet;

    move-result-object v0

    invoke-virtual {v10, v0}, Landroid/widget/LinearLayout;->setAnimation(Landroid/view/animation/Animation;)V

    .line 190
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 191
    const-string v15, "AUTHENTICATION"

    invoke-virtual {v0, v15}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 192
    const/16 v15, -0x2900

    invoke-virtual {v0, v15}, Landroid/widget/TextView;->setTextColor(I)V

    .line 193
    if-eqz v4, :cond_10e

    const/16 v15, 0x10

    goto :goto_110

    :cond_10e
    const/16 v15, 0x14

    :goto_110
    int-to-float v15, v15

    invoke-virtual {v0, v15}, Landroid/widget/TextView;->setTextSize(F)V

    .line 194
    sget-object v15, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v0, v15}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 195
    invoke-virtual {v0, v6}, Landroid/widget/TextView;->setGravity(I)V

    .line 196
    const/16 v15, 0xa

    int-to-float v6, v15

    const/4 v15, 0x0

    int-to-float v11, v15

    const/high16 v15, -0x1000000

    invoke-virtual {v0, v6, v11, v11, v15}, Landroid/widget/TextView;->setShadowLayer(FFFI)V

    .line 197
    invoke-virtual {v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 199
    invoke-static {v1, v10, v12}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->addSpacer(Landroid/content/Context;Landroid/widget/LinearLayout;I)V

    .line 201
    new-instance v6, Landroid/widget/EditText;

    invoke-direct {v6, v1}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    .line 202
    const-string v0, "Paste Key Here"

    invoke-virtual {v6, v0}, Landroid/widget/EditText;->setHint(Ljava/lang/CharSequence;)V

    .line 203
    const v0, -0x777778

    invoke-virtual {v6, v0}, Landroid/widget/EditText;->setHintTextColor(I)V

    .line 204
    const/4 v0, -0x1

    invoke-virtual {v6, v0}, Landroid/widget/EditText;->setTextColor(I)V

    .line 205
    const v0, -0xfafafb

    const v11, -0xe7e7e8

    filled-new-array {v0, v11}, [I

    move-result-object v0

    const v11, -0xcccccd

    const/16 v15, 0xf

    const/4 v3, 0x1

    invoke-static {v0, v3, v11, v15}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->createEmbossedBg([IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {v6, v0}, Landroid/widget/EditText;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 207
    if-eqz v4, :cond_15c

    const/16 v11, 0x14

    goto :goto_15e

    :cond_15c
    const/16 v11, 0x23

    .line 208
    :goto_15e
    const/16 v0, 0x28

    invoke-virtual {v6, v0, v11, v0, v11}, Landroid/widget/EditText;->setPadding(IIII)V

    .line 209
    const/4 v3, 0x1

    invoke-virtual {v6, v3}, Landroid/widget/EditText;->setSingleLine(Z)V

    .line 210
    if-eqz v4, :cond_16c

    const/16 v11, 0xc

    goto :goto_16e

    :cond_16c
    const/16 v11, 0xe

    :goto_16e
    int-to-float v11, v11

    invoke-virtual {v6, v11}, Landroid/widget/EditText;->setTextSize(F)V

    .line 211
    invoke-virtual {v10, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 213
    invoke-static {v1, v10, v12}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->addSpacer(Landroid/content/Context;Landroid/widget/LinearLayout;I)V

    .line 215
    sget-object v11, Lcom/osunhive/v3/osunhiveytgetkeyv3;->GRADIENT_METAL_BTN:[I

    const-string v15, "ADMIN"

    const/4 v0, -0x1

    invoke-static {v1, v15, v11, v0, v4}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->createEmbossedButton(Landroid/content/Context;Ljava/lang/String;[IIZ)Landroid/widget/Button;

    move-result-object v15

    .line 216
    new-instance v0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000001;

    invoke-direct {v0, v1}, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000001;-><init>(Landroid/app/Activity;)V

    invoke-virtual {v15, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 222
    invoke-virtual {v10, v15}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 224
    invoke-static {v1, v10, v12}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->addSpacer(Landroid/content/Context;Landroid/widget/LinearLayout;I)V

    .line 226
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 227
    const/4 v15, 0x0

    invoke-virtual {v0, v15}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 229
    new-instance v3, Landroid/widget/FrameLayout;

    invoke-direct {v3, v1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 230
    move-object/from16 v17, v6

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v18, v2

    move-object/from16 v19, v13

    const/4 v2, 0x1

    int-to-float v13, v2

    const/4 v2, -0x2

    invoke-direct {v6, v15, v2, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 231
    const/16 v2, 0xa

    invoke-virtual {v6, v15, v15, v2, v15}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 232
    invoke-virtual {v3, v6}, Landroid/widget/FrameLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 234
    const-string v2, "GET KEY"

    const/4 v6, -0x1

    invoke-static {v1, v2, v11, v6, v4}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->createEmbossedButton(Landroid/content/Context;Ljava/lang/String;[IIZ)Landroid/widget/Button;

    move-result-object v2

    .line 235
    new-instance v15, Landroid/widget/FrameLayout$LayoutParams;

    move-object/from16 v20, v14

    const/4 v14, -0x2

    invoke-direct {v15, v6, v14}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v15}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 237
    new-instance v6, Landroid/widget/ProgressBar;

    invoke-direct {v6, v1}, Landroid/widget/ProgressBar;-><init>(Landroid/content/Context;)V

    .line 238
    const/4 v14, 0x1

    invoke-virtual {v6, v14}, Landroid/widget/ProgressBar;->setIndeterminate(Z)V

    .line 239
    const/16 v14, 0x8

    invoke-virtual {v6, v14}, Landroid/widget/ProgressBar;->setVisibility(I)V

    .line 240
    if-eqz v4, :cond_1d8

    const/16 v14, 0x28

    goto :goto_1da

    :cond_1d8
    const/16 v14, 0x3c

    .line 241
    :goto_1da
    new-instance v15, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v15, v14, v14}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 242
    const/16 v14, 0x11

    iput v14, v15, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 243
    invoke-virtual {v6, v15}, Landroid/widget/ProgressBar;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 244
    invoke-virtual {v6}, Landroid/widget/ProgressBar;->getIndeterminateDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v14

    sget-object v15, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    move-object/from16 v16, v9

    const/4 v9, -0x1

    invoke-virtual {v14, v9, v15}, Landroid/graphics/drawable/Drawable;->setColorFilter(ILandroid/graphics/PorterDuff$Mode;)V

    .line 246
    invoke-virtual {v3, v2}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    .line 247
    invoke-virtual {v3, v6}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    .line 249
    const-string v14, "PASTE"

    invoke-static {v1, v14, v11, v9, v4}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->createEmbossedButton(Landroid/content/Context;Ljava/lang/String;[IIZ)Landroid/widget/Button;

    move-result-object v9

    .line 250
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v14, -0x2

    const/4 v15, 0x0

    invoke-direct {v11, v15, v14, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 251
    const/16 v13, 0xa

    invoke-virtual {v11, v13, v15, v15, v15}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 252
    invoke-virtual {v9, v11}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 254
    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 255
    invoke-virtual {v0, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 256
    invoke-virtual {v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 258
    invoke-static {v1, v10, v12}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->addSpacer(Landroid/content/Context;Landroid/widget/LinearLayout;I)V

    .line 260
    const-string v0, "UNLOCK DEVICE"

    sget-object v3, Lcom/osunhive/v3/osunhiveytgetkeyv3;->GRADIENT_GOLD:[I

    const/high16 v11, -0x1000000

    invoke-static {v1, v0, v3, v11, v4}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->createEmbossedButton(Landroid/content/Context;Ljava/lang/String;[IIZ)Landroid/widget/Button;

    move-result-object v3

    .line 261
    invoke-virtual {v10, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 264
    new-instance v11, Landroid/widget/ImageView;

    invoke-direct {v11, v1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 266
    :try_start_22b
    invoke-virtual/range {p0 .. p0}, Landroid/app/Activity;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v0

    .line 267
    const-string v12, "dp.png"

    invoke-virtual {v0, v12}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0

    .line 268
    invoke-static {v0}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object v12

    .line 269
    invoke-virtual {v11, v12}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    .line 270
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V
    :try_end_23f
    .catch Ljava/io/IOException; {:try_start_22b .. :try_end_23f} :catch_240

    goto :goto_247

    :catch_240
    move-exception v0

    .line 271
    const v0, 0x108002f

    invoke-virtual {v11, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 273
    :goto_247
    new-instance v0, Landroid/widget/RelativeLayout$LayoutParams;

    invoke-direct {v0, v7, v7}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    .line 274
    const/16 v7, 0xe

    invoke-virtual {v0, v7}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    .line 275
    const/4 v7, 0x6

    invoke-virtual {v0, v7, v8}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(II)V

    .line 277
    neg-int v5, v5

    iput v5, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 278
    invoke-virtual {v11, v0}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 279
    invoke-static {}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->getDropInAnim()Landroid/view/animation/AnimationSet;

    move-result-object v0

    invoke-virtual {v11, v0}, Landroid/widget/ImageView;->setAnimation(Landroid/view/animation/Animation;)V

    .line 280
    const/high16 v0, 0x42200000  # 40.0f

    invoke-virtual {v11, v0}, Landroid/widget/ImageView;->setElevation(F)V

    .line 283
    if-nez v4, :cond_293

    .line 284
    const-string v0, "L.png"

    invoke-static {v1, v0}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->createCornerDecoration(Landroid/content/Context;Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    .line 285
    if-eqz v0, :cond_290

    .line 286
    new-instance v4, Landroid/widget/RelativeLayout$LayoutParams;

    const/16 v5, 0x320

    invoke-direct {v4, v5, v5}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    .line 287
    const/16 v5, 0xe

    invoke-virtual {v4, v5}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    .line 288
    invoke-virtual {v4, v7, v8}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(II)V

    .line 289
    const/16 v5, -0x190

    iput v5, v4, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 290
    invoke-virtual {v0, v4}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 291
    invoke-static {v0}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->startSpinAnimation(Landroid/view/View;)V

    .line 292
    move-object/from16 v4, v16

    invoke-virtual {v4, v0}, Landroid/widget/RelativeLayout;->addView(Landroid/view/View;)V

    goto :goto_295

    .line 285
    :cond_290
    move-object/from16 v4, v16

    goto :goto_295

    .line 283
    :cond_293
    move-object/from16 v4, v16

    .line 296
    :goto_295
    invoke-virtual {v4, v10}, Landroid/widget/RelativeLayout;->addView(Landroid/view/View;)V

    .line 297
    invoke-virtual {v4, v11}, Landroid/widget/RelativeLayout;->addView(Landroid/view/View;)V

    .line 299
    move-object/from16 v5, v20

    invoke-virtual {v5, v4}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    .line 300
    move-object/from16 v4, v19

    invoke-virtual {v4, v5}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 301
    move-object/from16 v5, v18

    invoke-virtual {v5, v4}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    .line 304
    new-instance v0, Ljava/lang/StringBuffer;

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    const-string v4, "OS"

    invoke-virtual {v0, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    new-instance v4, Ljava/util/Random;

    invoke-direct {v4}, Ljava/util/Random;-><init>()V

    const v7, 0x15f8f

    invoke-virtual {v4, v7}, Ljava/util/Random;->nextInt(I)I

    move-result v4

    add-int/lit16 v4, v4, 0x2710

    invoke-virtual {v0, v4}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->currentSessionKey:Ljava/lang/String;

    .line 306
    new-instance v0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;

    invoke-direct {v0, v2, v6, v1}, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;-><init>(Landroid/widget/Button;Landroid/widget/ProgressBar;Landroid/app/Activity;)V

    invoke-virtual {v2, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 326
    new-instance v0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000004;

    move-object/from16 v2, v17

    invoke-direct {v0, v1, v2}, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000004;-><init>(Landroid/app/Activity;Landroid/widget/EditText;)V

    invoke-virtual {v9, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 334
    new-instance v0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000005;

    invoke-direct {v0, v2, v1, v5}, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000005;-><init>(Landroid/widget/EditText;Landroid/app/Activity;Landroid/app/Dialog;)V

    invoke-virtual {v3, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 346
    invoke-virtual {v5}, Landroid/app/Dialog;->show()V

    .line 347
    sget-object v0, Lcom/osunhive/v3/osunhiveytgetkeyv3;->fetchedApiUrl:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_301

    new-instance v0, Lcom/osunhive/v3/osunhiveytgetkeyv3$FetchConfigTask;

    const/4 v1, 0x0

    move-object v2, v1

    check-cast v2, Ljava/lang/Runnable;

    invoke-direct {v0, v1}, Lcom/osunhive/v3/osunhiveytgetkeyv3$FetchConfigTask;-><init>(Ljava/lang/Runnable;)V

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/Void;

    invoke-virtual {v0, v1}, Lcom/osunhive/v3/osunhiveytgetkeyv3$FetchConfigTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    :cond_301
    return-void
.end method

.method private static showNoInternetDialog(Landroid/app/Activity;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            ")V"
        }
    .end annotation

    .line 478
    new-instance v0, Landroid/app/Dialog;

    const v1, 0x103000a

    invoke-direct {v0, p0, v1}, Landroid/app/Dialog;-><init>(Landroid/content/Context;I)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setCancelable(Z)V

    .line 479
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v3, 0x11

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v3, -0x1000000

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 480
    sget-object v3, Lcom/osunhive/v3/osunhiveytgetkeyv3;->GRADIENT_METAL_BTN:[I

    const/4 v4, -0x1

    const-string v5, "RETRY"

    invoke-static {p0, v5, v3, v4, v1}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->createEmbossedButton(Landroid/content/Context;Ljava/lang/String;[IIZ)Landroid/widget/Button;

    move-result-object v1

    .line 481
    new-instance v3, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000006;

    invoke-direct {v3, p0, v0}, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000006;-><init>(Landroid/app/Activity;Landroid/app/Dialog;)V

    invoke-virtual {v1, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 482
    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-virtual {v0, v2}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method private static startSpinAnimation(Landroid/view/View;)V
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .line 380
    new-instance v7, Landroid/view/animation/RotateAnimation;

    const/4 v0, 0x0

    int-to-float v1, v0

    const/16 v0, 0x168

    int-to-float v2, v0

    const/4 v3, 0x1

    const/high16 v4, 0x3f000000  # 0.5f

    const/4 v5, 0x1

    const/high16 v6, 0x3f000000  # 0.5f

    move-object v0, v7

    invoke-direct/range {v0 .. v6}, Landroid/view/animation/RotateAnimation;-><init>(FFIFIF)V

    .line 381
    const/16 v0, 0x1770

    int-to-long v0, v0

    invoke-virtual {v7, v0, v1}, Landroid/view/animation/RotateAnimation;->setDuration(J)V

    .line 382
    const/4 v0, -0x1

    invoke-virtual {v7, v0}, Landroid/view/animation/RotateAnimation;->setRepeatCount(I)V

    .line 383
    new-instance v0, Landroid/view/animation/LinearInterpolator;

    invoke-direct {v0}, Landroid/view/animation/LinearInterpolator;-><init>()V

    invoke-virtual {v7, v0}, Landroid/view/animation/RotateAnimation;->setInterpolator(Landroid/view/animation/Interpolator;)V

    .line 384
    invoke-virtual {p0, v7}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    return-void
.end method

.method private static triggerSecurityProtocol(Landroid/app/Activity;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            ")V"
        }
    .end annotation

    .line 105
    new-instance v0, Ljava/lang/StringBuffer;

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v1, Ljava/lang/StringBuffer;

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    sget-object v2, Lcom/osunhive/v3/osunhiveytgetkeyv3;->L1:[I

    invoke-static {v2}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->d([I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v1

    sget-object v2, Lcom/osunhive/v3/osunhiveytgetkeyv3;->L2:[I

    invoke-static {v2}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->d([I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    sget-object v1, Lcom/osunhive/v3/osunhiveytgetkeyv3;->L3:[I

    invoke-static {v1}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->d([I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    .line 106
    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.intent.action.VIEW"

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    invoke-direct {v1, v2, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 107
    const v0, 0x10008000

    invoke-virtual {v1, v0}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 108
    invoke-virtual {p0, v1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    .line 109
    new-instance p0, Landroid/os/Handler;

    invoke-direct {p0}, Landroid/os/Handler;-><init>()V

    new-instance v0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000000;

    invoke-direct {v0}, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000000;-><init>()V

    const/16 v1, 0x3e8

    int-to-long v1, v1

    invoke-virtual {p0, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
