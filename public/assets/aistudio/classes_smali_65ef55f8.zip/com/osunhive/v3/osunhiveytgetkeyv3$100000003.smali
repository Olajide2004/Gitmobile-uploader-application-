.class Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;
.super Ljava/lang/Object;
.source "osunhiveytgetkeyv3.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/osunhive/v3/osunhiveytgetkeyv3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000003"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003$100000002;
    }
.end annotation


# instance fields
.field private final synthetic val$activity:Landroid/app/Activity;

.field private final synthetic val$btnGetKey:Landroid/widget/Button;

.field private final synthetic val$progressBar:Landroid/widget/ProgressBar;


# direct methods
.method constructor <init>(Landroid/widget/Button;Landroid/widget/ProgressBar;Landroid/app/Activity;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;->val$btnGetKey:Landroid/widget/Button;

    iput-object p2, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;->val$progressBar:Landroid/widget/ProgressBar;

    iput-object p3, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;->val$activity:Landroid/app/Activity;

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .line 308
    iget-object p1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;->val$btnGetKey:Landroid/widget/Button;

    const-string v0, ""

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 309
    iget-object p1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;->val$btnGetKey:Landroid/widget/Button;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setEnabled(Z)V

    .line 310
    iget-object p1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;->val$progressBar:Landroid/widget/ProgressBar;

    invoke-virtual {p1, v0}, Landroid/widget/ProgressBar;->setVisibility(I)V

    .line 312
    invoke-static {}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->access$L1000017()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_32

    .line 313
    new-instance p1, Lcom/osunhive/v3/osunhiveytgetkeyv3$FetchConfigTask;

    new-instance v1, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003$100000002;

    iget-object v2, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;->val$activity:Landroid/app/Activity;

    iget-object v3, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;->val$btnGetKey:Landroid/widget/Button;

    iget-object v4, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;->val$progressBar:Landroid/widget/ProgressBar;

    invoke-direct {v1, p0, v2, v3, v4}, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003$100000002;-><init>(Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;Landroid/app/Activity;Landroid/widget/Button;Landroid/widget/ProgressBar;)V

    invoke-direct {p1, v1}, Lcom/osunhive/v3/osunhiveytgetkeyv3$FetchConfigTask;-><init>(Ljava/lang/Runnable;)V

    new-array v0, v0, [Ljava/lang/Void;

    invoke-virtual {p1, v0}, Lcom/osunhive/v3/osunhiveytgetkeyv3$FetchConfigTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    goto :goto_76

    .line 320
    :cond_32
    new-instance p1, Ljava/lang/StringBuffer;

    invoke-direct {p1}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v0, Ljava/lang/StringBuffer;

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    const-string v1, "https://www.osunhive.name.ng/p/key-by-osunhive.html"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    const-string v1, "?"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object p1

    invoke-static {}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->access$L1000016()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p1

    .line 321
    new-instance v0, Lcom/osunhive/v3/osunhiveytgetkeyv3$ShortenUrlTask;

    iget-object v1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;->val$activity:Landroid/app/Activity;

    iget-object v2, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;->val$btnGetKey:Landroid/widget/Button;

    iget-object v3, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;->val$progressBar:Landroid/widget/ProgressBar;

    invoke-direct {v0, v1, v2, v3}, Lcom/osunhive/v3/osunhiveytgetkeyv3$ShortenUrlTask;-><init>(Landroid/app/Activity;Landroid/widget/Button;Landroid/widget/ProgressBar;)V

    invoke-static {}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->access$L1000017()Ljava/lang/String;

    move-result-object v1

    invoke-static {}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->access$L1000018()Ljava/lang/String;

    move-result-object v2

    filled-new-array {v1, v2, p1}, [Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcom/osunhive/v3/osunhiveytgetkeyv3$ShortenUrlTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    :goto_76
    return-void
.end method
