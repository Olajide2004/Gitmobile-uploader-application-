.class Lcom/osunhive/v3/osunhiveytgetkeyv3$VerifyTimeTask;
.super Landroid/os/AsyncTask;
.source "osunhiveytgetkeyv3.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/osunhive/v3/osunhiveytgetkeyv3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2a
    name = "VerifyTimeTask"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/Void;",
        "Ljava/lang/Void;",
        "Ljava/lang/Long;",
        ">;"
    }
.end annotation


# instance fields
.field act:Landroid/app/Activity;

.field d:Landroid/app/Dialog;

.field isInitialCheck:Z


# direct methods
.method constructor <init>(Landroid/app/Activity;Landroid/app/Dialog;Z)V
    .registers 4

    .line 447
    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    iput-object p1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$VerifyTimeTask;->act:Landroid/app/Activity;

    iput-object p2, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$VerifyTimeTask;->d:Landroid/app/Dialog;

    iput-boolean p3, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$VerifyTimeTask;->isInitialCheck:Z

    return-void
.end method


# virtual methods
.method protected varargs doInBackground([Ljava/lang/Void;)Ljava/lang/Long;
    .registers 6
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 449
    :try_start_0
    new-instance p1, Ljava/net/URL;

    const-string v0, "https://www.google.com"

    invoke-direct {p1, v0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object p1

    check-cast p1, Ljava/net/HttpURLConnection;

    const-string v0, "HEAD"

    invoke-virtual {p1, v0}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->getDate()J

    move-result-wide v0

    const/4 p1, 0x0

    int-to-long v2, p1

    cmp-long p1, v0, v2

    if-nez p1, :cond_20

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    :cond_20
    new-instance p1, Ljava/lang/Long;

    invoke-direct {p1, v0, v1}, Ljava/lang/Long;-><init>(J)V
    :try_end_25
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_25} :catch_26

    return-object p1

    :catch_26
    move-exception p1

    new-instance p1, Ljava/lang/Long;

    const-wide/16 v0, 0x0

    invoke-direct {p1, v0, v1}, Ljava/lang/Long;-><init>(J)V

    return-object p1
.end method

.method protected bridge doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    check-cast p1, [Ljava/lang/Void;

    invoke-virtual {p0, p1}, Lcom/osunhive/v3/osunhiveytgetkeyv3$VerifyTimeTask;->doInBackground([Ljava/lang/Void;)Ljava/lang/Long;

    move-result-object p1

    return-object p1
.end method

.method protected onPostExecute(Ljava/lang/Long;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Long;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 452
    move-object v0, p1

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v2, 0x0

    int-to-long v3, v2

    cmp-long v5, v0, v3

    if-nez v5, :cond_23

    iget-boolean p1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$VerifyTimeTask;->isInitialCheck:Z

    if-nez p1, :cond_1d

    iget-object p1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$VerifyTimeTask;->act:Landroid/app/Activity;

    const-string v0, "Connection Error"

    invoke-static {p1, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    goto :goto_22

    :cond_1d
    iget-object p1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$VerifyTimeTask;->act:Landroid/app/Activity;

    invoke-static {p1}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->access$1000028(Landroid/app/Activity;)V

    :goto_22
    return-void

    .line 453
    :cond_23
    iget-object v0, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$VerifyTimeTask;->act:Landroid/app/Activity;

    const-string v1, "OsunhiveKeyPrefs"

    invoke-virtual {v0, v1, v2}, Landroid/app/Activity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 454
    iget-boolean v1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$VerifyTimeTask;->isInitialCheck:Z

    const-string v5, "expiry_time_server"

    if-eqz v1, :cond_4f

    .line 455
    invoke-interface {v0, v5, v3, v4}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v0

    .line 456
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    cmp-long p1, v3, v0

    if-gez p1, :cond_49

    iget-object p1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$VerifyTimeTask;->act:Landroid/app/Activity;

    const-string v0, "License Active"

    invoke-static {p1, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    goto :goto_75

    :cond_49
    iget-object p1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$VerifyTimeTask;->act:Landroid/app/Activity;

    invoke-static {p1}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->access$1000028(Landroid/app/Activity;)V

    goto :goto_75

    .line 458
    :cond_4f
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const p1, 0x5265c00

    int-to-long v3, p1

    add-long/2addr v1, v3

    invoke-interface {v0, v5, v1, v2}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    iget-object p1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$VerifyTimeTask;->act:Landroid/app/Activity;

    const-string v0, "Unlocked (24 Hours)"

    const/4 v1, 0x1

    invoke-static {p1, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    iget-object p1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$VerifyTimeTask;->d:Landroid/app/Dialog;

    if-eqz p1, :cond_75

    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    :cond_75
    :goto_75
    return-void
.end method

.method protected bridge onPostExecute(Ljava/lang/Object;)V
    .registers 2

    check-cast p1, Ljava/lang/Long;

    invoke-virtual {p0, p1}, Lcom/osunhive/v3/osunhiveytgetkeyv3$VerifyTimeTask;->onPostExecute(Ljava/lang/Long;)V

    return-void
.end method
