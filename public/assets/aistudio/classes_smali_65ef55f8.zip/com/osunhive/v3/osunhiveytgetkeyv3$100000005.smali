.class Lcom/osunhive/v3/osunhiveytgetkeyv3$100000005;
.super Ljava/lang/Object;
.source "osunhiveytgetkeyv3.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/osunhive/v3/osunhiveytgetkeyv3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000005"
.end annotation


# instance fields
.field private final synthetic val$activity:Landroid/app/Activity;

.field private final synthetic val$dialog:Landroid/app/Dialog;

.field private final synthetic val$inputKey:Landroid/widget/EditText;


# direct methods
.method constructor <init>(Landroid/widget/EditText;Landroid/app/Activity;Landroid/app/Dialog;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000005;->val$inputKey:Landroid/widget/EditText;

    iput-object p2, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000005;->val$activity:Landroid/app/Activity;

    iput-object p3, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000005;->val$dialog:Landroid/app/Dialog;

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .line 336
    iget-object p1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000005;->val$inputKey:Landroid/widget/EditText;

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    .line 337
    invoke-static {}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->access$L1000016()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v0, 0x0

    if-eqz p1, :cond_28

    .line 338
    new-instance p1, Lcom/osunhive/v3/osunhiveytgetkeyv3$VerifyTimeTask;

    iget-object v1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000005;->val$activity:Landroid/app/Activity;

    iget-object v2, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000005;->val$dialog:Landroid/app/Dialog;

    invoke-direct {p1, v1, v2, v0}, Lcom/osunhive/v3/osunhiveytgetkeyv3$VerifyTimeTask;-><init>(Landroid/app/Activity;Landroid/app/Dialog;Z)V

    new-array v0, v0, [Ljava/lang/Void;

    invoke-virtual {p1, v0}, Lcom/osunhive/v3/osunhiveytgetkeyv3$VerifyTimeTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    goto :goto_3a

    .line 340
    :cond_28
    iget-object p1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000005;->val$activity:Landroid/app/Activity;

    const-string v1, "Invalid Key"

    invoke-static {p1, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 341
    iget-object p1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000005;->val$inputKey:Landroid/widget/EditText;

    const-string v0, "X"

    invoke-virtual {p1, v0}, Landroid/widget/EditText;->setError(Ljava/lang/CharSequence;)V

    :goto_3a
    return-void
.end method
