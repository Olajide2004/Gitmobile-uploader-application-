.class Lcom/osunhive/v3/osunhiveytgetkeyv3$100000006;
.super Ljava/lang/Object;
.source "osunhiveytgetkeyv3.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/osunhive/v3/osunhiveytgetkeyv3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000006"
.end annotation


# instance fields
.field private final synthetic val$activity:Landroid/app/Activity;

.field private final synthetic val$d:Landroid/app/Dialog;


# direct methods
.method constructor <init>(Landroid/app/Activity;Landroid/app/Dialog;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000006;->val$activity:Landroid/app/Activity;

    iput-object p2, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000006;->val$d:Landroid/app/Dialog;

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .line 481
    iget-object p1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000006;->val$activity:Landroid/app/Activity;

    invoke-static {p1}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->access$1000036(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_12

    iget-object p1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000006;->val$d:Landroid/app/Dialog;

    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    iget-object p1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000006;->val$activity:Landroid/app/Activity;

    invoke-static {p1}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->getkeybydp(Landroid/app/Activity;)V

    :cond_12
    return-void
.end method
