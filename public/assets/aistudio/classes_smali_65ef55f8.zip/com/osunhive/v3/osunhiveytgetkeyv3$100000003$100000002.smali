.class Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003$100000002;
.super Ljava/lang/Object;
.source "osunhiveytgetkeyv3.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000002"
.end annotation


# instance fields
.field private final this$0:Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;

.field private final synthetic val$activity:Landroid/app/Activity;

.field private final synthetic val$btnGetKey:Landroid/widget/Button;

.field private final synthetic val$progressBar:Landroid/widget/ProgressBar;


# direct methods
.method constructor <init>(Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;Landroid/app/Activity;Landroid/widget/Button;Landroid/widget/ProgressBar;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003$100000002;->this$0:Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;

    iput-object p2, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003$100000002;->val$activity:Landroid/app/Activity;

    iput-object p3, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003$100000002;->val$btnGetKey:Landroid/widget/Button;

    iput-object p4, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003$100000002;->val$progressBar:Landroid/widget/ProgressBar;

    return-void
.end method

.method static access$0(Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003$100000002;)Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;
    .registers 1

    iget-object p0, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003$100000002;->this$0:Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003;

    return-object p0
.end method


# virtual methods
.method public run()V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .line 315
    new-instance v0, Ljava/lang/StringBuffer;

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v1, Ljava/lang/StringBuffer;

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    const-string v2, "https://www.osunhive.name.ng/p/key-by-osunhive.html"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v1

    const-string v2, "?"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-static {}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->access$L1000016()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    .line 316
    new-instance v1, Lcom/osunhive/v3/osunhiveytgetkeyv3$ShortenUrlTask;

    iget-object v2, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003$100000002;->val$activity:Landroid/app/Activity;

    iget-object v3, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003$100000002;->val$btnGetKey:Landroid/widget/Button;

    iget-object v4, p0, Lcom/osunhive/v3/osunhiveytgetkeyv3$100000003$100000002;->val$progressBar:Landroid/widget/ProgressBar;

    invoke-direct {v1, v2, v3, v4}, Lcom/osunhive/v3/osunhiveytgetkeyv3$ShortenUrlTask;-><init>(Landroid/app/Activity;Landroid/widget/Button;Landroid/widget/ProgressBar;)V

    invoke-static {}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->access$L1000017()Ljava/lang/String;

    move-result-object v2

    invoke-static {}, Lcom/osunhive/v3/osunhiveytgetkeyv3;->access$L1000018()Ljava/lang/String;

    move-result-object v3

    filled-new-array {v2, v3, v0}, [Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lcom/osunhive/v3/osunhiveytgetkeyv3$ShortenUrlTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    return-void
.end method
